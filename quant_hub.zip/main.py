# -*- coding: utf-8 -*-
import json
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def main_handler(event, context):
    """腾讯云函数入口"""
    print("策略执行开始")
    
    try:
        # 延迟导入，避免循环依赖
        from 核心.核心引擎 import CoreEngine
        from 资金管理模块.capital_allocator import CapitalAllocator
        from 风控模块.risk_manager import RiskManager
        from 策略库.外汇策略.外汇利差策略 import ForexCarryStrategy
        from 策略库.外汇策略.外汇突破策略 import ForexBreakoutStrategy
        from 策略库.外汇策略.外汇双均线 import ForexDualMAStrategy
        from 策略库.期货策略.期货趋势策略 import FuturesTrendStrategy
        from 策略库.期货策略.期货均值回归 import FuturesMeanReversionStrategy
        from 策略库.期货策略.期货ATR import FuturesATRStrategy
        from 策略库.加密货币策略.加密双均线策略 import CryptoDualMAStrategy
        from 策略库.加密货币策略.加密RSI策略 import CryptoRSIStrategy
        
        total_capital = 80050
        capital_mgr = CapitalAllocator(total_capital=total_capital)
        risk_mgr = RiskManager(max_drawdown=0.15)
        
        strategies = [
            ForexCarryStrategy("外汇利差", "AUDJPY", 0),
            ForexBreakoutStrategy("外汇突破", "EURUSD", 0),
            ForexDualMAStrategy("外汇双均线", "GBPUSD", 0),
            FuturesTrendStrategy("期货趋势", "GC=F", 0),
            FuturesMeanReversionStrategy("期货均值回归", "CL=F", 0),
            FuturesATRStrategy("期货ATR", "SI=F", 0),
            CryptoDualMAStrategy("加密双均线", "BTC-USD", 0),
            CryptoRSIStrategy("加密RSI", "ETH-USD", 0),
        ]
        
        capital_mgr.allocate(strategies)
        
        print("\n📋 策略列表:")
        for s in strategies:
            print(f"   📈 {s.name} - {s.symbol} - 资金: ${s.capital:,.2f}")
        
        print(f"\n💰 总资金: ${capital_mgr.total_capital:,.2f}")
        print("🚀 核心引擎启动")
        print(f"📊 共加载 {len(strategies)} 个策略\n")
        
        engine = CoreEngine(
            strategies=strategies,
            capital_manager=capital_mgr,
            risk_manager=risk_mgr
        )
        engine.run()
        
        return {
            "statusCode": 200,
            "body": json.dumps({"status": "success"})
        }
    except Exception as e:
        print(f"执行失败: {e}")
        import traceback
        traceback.print_exc()
        return {
            "statusCode": 500,
            "body": json.dumps({"status": "error", "message": str(e)})
        }