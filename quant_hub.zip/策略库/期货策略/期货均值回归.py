# -*- coding: utf-8 -*-
import sys
import os
import math
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from ..策略基类 import BaseStrategy

class FuturesMeanReversionStrategy(BaseStrategy):
    """期货均值回归策略：布林带下轨买入，上轨卖出"""
    
    def __init__(self, name, symbol, initial_capital, window=20, num_std=2):
        super().__init__(name, symbol, initial_capital)
        self.window = window
        self.num_std = num_std
        self.prices = []
        
    def on_data(self, kline):
        self.prices.append(kline['close'])
        
        if len(self.prices) < self.window:
            return 'hold'
        
        recent = self.prices[-self.window:]
        mean = sum(recent) / self.window
        variance = sum((p - mean) ** 2 for p in recent) / self.window
        std = math.sqrt(variance)
        
        upper = mean + self.num_std * std
        lower = mean - self.num_std * std
        price = kline['close']
        
        if price <= lower:
            return 'buy'
        elif price >= upper:
            return 'sell'
        return 'hold'